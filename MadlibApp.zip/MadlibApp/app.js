var express = require('express');
var app = express();

// Configuration

// app.configure(function(){
//     app.use(express.bodyParser());
//     app.use(app.router);
//     app.use(express.static(__dirname + '/public'));
//   });
  
  app.set('view engine', 'ejs');
  app.set('view options', {
      layout: false
  });
  
  app.get('/', function(req, res) {
    res.render('home', {
      message : 'Connected'
    });
  });

  app.get('/create', function(req, res) {
    res.render('create', {
      message : 'Connected'
    });
  });

  app.post('/completed', function(req, res) {
    res.render('completed', {
      message : 'Connected'
    });
  });

  app.use(express.static(__dirname + "/public"));
  
  app.listen(3000);
  
  console.log("Connected!");